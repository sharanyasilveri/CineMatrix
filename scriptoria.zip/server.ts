import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import { GoogleGenAI, Type } from "@google/genai";
import PDFDocument from "pdfkit";
import { Document, Packer, Paragraph, TextRun, HeadingLevel } from "docx";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Initialize Database
const db = new Database("scriptoria.db");
db.exec(`
  CREATE TABLE IF NOT EXISTS stories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    story_idea TEXT,
    genre TEXT,
    mood TEXT,
    screenplay TEXT,
    characters TEXT,
    sound_design TEXT,
    production_notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // AI Setup
  const genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

  // API Routes
  app.post("/api/generate", async (req, res) => {
    const { storyIdea, genre, mood } = req.body;

    if (!storyIdea) {
      return res.status(400).json({ error: "Story idea is required" });
    }

    try {
      const model = "gemini-3.1-pro-preview";
      const prompt = `
        Act as a professional film producer and screenwriter. 
        Transform the following story idea into a comprehensive film pre-production blueprint.
        
        STORY IDEA: ${storyIdea}
        GENRE: ${genre}
        MOOD: ${mood}

        Provide the output in JSON format with the following structure:
        {
          "screenplay": "A detailed 5-7 scene outline with titles and descriptions.",
          "characters": "A list of main characters with Name, Role, Personality, and Character Arc.",
          "soundDesign": "Music styles and sound effects suggestions for key scenes.",
          "productionNotes": "Ideas for cinematography, lighting, and set design."
        }
      `;

      const result = await genAI.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              screenplay: { type: Type.STRING },
              characters: { type: Type.STRING },
              soundDesign: { type: Type.STRING },
              productionNotes: { type: Type.STRING },
            },
            required: ["screenplay", "characters", "soundDesign", "productionNotes"],
          },
        },
      });

      const blueprint = JSON.parse(result.text || "{}");

      // Save to Database
      const stmt = db.prepare(`
        INSERT INTO stories (story_idea, genre, mood, screenplay, characters, sound_design, production_notes)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);
      const info = stmt.run(
        storyIdea,
        genre,
        mood,
        blueprint.screenplay,
        blueprint.characters,
        blueprint.soundDesign,
        blueprint.productionNotes
      );

      res.json({ id: info.lastInsertRowid, ...blueprint });
    } catch (error) {
      console.error("AI Generation Error:", error);
      res.status(500).json({ error: "Failed to generate film blueprint" });
    }
  });

  // Export Routes
  app.get("/api/export/:id/:format", (req, res) => {
    const { id, format } = req.params;
    const story = db.prepare("SELECT * FROM stories WHERE id = ?").get(id) as any;

    if (!story) return res.status(404).send("Story not found");

    const content = `
SCRIPTORIA - FILM BLUEPRINT
---------------------------
ID: ${story.id}
GENRE: ${story.genre}
MOOD: ${story.mood}
STORY IDEA: ${story.story_idea}

SCREENPLAY OUTLINE:
${story.screenplay}

CHARACTER PROFILES:
${story.characters}

SOUND DESIGN PLAN:
${story.sound_design}

PRODUCTION NOTES:
${story.production_notes}
    `;

    if (format === "txt") {
      res.setHeader("Content-Type", "text/plain");
      res.setHeader("Content-Disposition", `attachment; filename=blueprint_${id}.txt`);
      return res.send(content);
    }

    if (format === "pdf") {
      const doc = new PDFDocument();
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename=blueprint_${id}.pdf`);
      doc.pipe(res);
      doc.fontSize(20).text("SCRIPTORIA - FILM BLUEPRINT", { align: "center" });
      doc.moveDown();
      doc.fontSize(12).text(`Genre: ${story.genre}`);
      doc.text(`Mood: ${story.mood}`);
      doc.moveDown();
      doc.fontSize(14).text("Story Idea:", { underline: true });
      doc.fontSize(12).text(story.story_idea);
      doc.moveDown();
      doc.fontSize(14).text("Screenplay Outline:", { underline: true });
      doc.fontSize(12).text(story.screenplay);
      doc.moveDown();
      doc.fontSize(14).text("Character Profiles:", { underline: true });
      doc.fontSize(12).text(story.characters);
      doc.moveDown();
      doc.fontSize(14).text("Sound Design:", { underline: true });
      doc.fontSize(12).text(story.sound_design);
      doc.moveDown();
      doc.fontSize(14).text("Production Notes:", { underline: true });
      doc.fontSize(12).text(story.production_notes);
      doc.end();
      return;
    }

    if (format === "docx") {
      const doc = new Document({
        sections: [{
          properties: {},
          children: [
            new Paragraph({ text: "SCRIPTORIA - FILM BLUEPRINT", heading: HeadingLevel.HEADING_1 }),
            new Paragraph({ children: [new TextRun({ text: `Genre: ${story.genre}`, bold: true })] }),
            new Paragraph({ children: [new TextRun({ text: `Mood: ${story.mood}`, bold: true })] }),
            new Paragraph({ text: "\nStory Idea:", heading: HeadingLevel.HEADING_2 }),
            new Paragraph({ text: story.story_idea }),
            new Paragraph({ text: "\nScreenplay Outline:", heading: HeadingLevel.HEADING_2 }),
            new Paragraph({ text: story.screenplay }),
            new Paragraph({ text: "\nCharacter Profiles:", heading: HeadingLevel.HEADING_2 }),
            new Paragraph({ text: story.characters }),
            new Paragraph({ text: "\nSound Design:", heading: HeadingLevel.HEADING_2 }),
            new Paragraph({ text: story.sound_design }),
            new Paragraph({ text: "\nProduction Notes:", heading: HeadingLevel.HEADING_2 }),
            new Paragraph({ text: story.production_notes }),
          ],
        }],
      });

      Packer.toBuffer(doc).then((buffer) => {
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        res.setHeader("Content-Disposition", `attachment; filename=blueprint_${id}.docx`);
        res.send(buffer);
      });
      return;
    }

    res.status(400).send("Invalid format");
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
