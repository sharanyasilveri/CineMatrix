/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { 
  Film, 
  Sparkles, 
  Music, 
  Users, 
  Clapperboard, 
  Download, 
  Loader2, 
  ChevronDown,
  ScrollText,
  Camera
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface Blueprint {
  id: number;
  screenplay: string;
  characters: string;
  soundDesign: string;
  productionNotes: string;
}

const GENRES = ["Sci-Fi", "Drama", "Horror", "Comedy", "Fantasy", "Thriller"];
const MOODS = ["Epic", "Dark", "Emotional", "Suspenseful", "Vibrant", "Mysterious"];

export default function App() {
  const [storyIdea, setStoryIdea] = useState("");
  const [genre, setGenre] = useState(GENRES[0]);
  const [mood, setMood] = useState(MOODS[0]);
  const [loading, setLoading] = useState(false);
  const [blueprint, setBlueprint] = useState<Blueprint | null>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  const handleGenerate = async () => {
    if (!storyIdea.trim()) return;
    
    setLoading(true);
    setBlueprint(null);
    
    try {
      const response = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ storyIdea, genre, mood }),
      });
      
      if (!response.ok) throw new Error("Generation failed");
      
      const data = await response.json();
      setBlueprint(data);
      
      // Scroll to results
      setTimeout(() => {
        resultsRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);
    } catch (error) {
      console.error(error);
      alert("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleExport = (format: string) => {
    if (!blueprint) return;
    window.open(`/api/export/${blueprint.id}/${format}`, "_blank");
  };

  return (
    <div className="min-h-screen bg-[#0f172a] text-slate-100 font-sans selection:bg-indigo-500/30">
      {/* Hero Section */}
      <header className="relative h-screen flex flex-col items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-[#0f172a] z-10" />
          <img 
            src="https://images.unsplash.com/photo-1485846234645-a62644f84728?auto=format&fit=crop&q=80&w=2000" 
            alt="Cinema background" 
            className="w-full h-full object-cover opacity-30 scale-105 animate-pulse"
            referrerPolicy="no-referrer"
          />
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative z-20 text-center px-4"
        >
          <div className="flex items-center justify-center mb-6">
            <div className="p-3 bg-indigo-600 rounded-2xl shadow-lg shadow-indigo-500/50">
              <Film className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="text-7xl md:text-9xl font-black tracking-tighter mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-200 to-indigo-500">
            SCRIPTORIA
          </h1>
          <p className="text-xl md:text-2xl text-slate-400 font-light tracking-widest uppercase mb-12">
            AI Powered Film Pre-Production Assistant
          </p>
          <button 
            onClick={() => document.getElementById("input-section")?.scrollIntoView({ behavior: "smooth" })}
            className="group relative px-8 py-4 bg-white text-black font-bold rounded-full overflow-hidden transition-all hover:scale-105 active:scale-95"
          >
            <span className="relative z-10">START CREATING</span>
            <div className="absolute inset-0 bg-indigo-500 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          </button>
        </motion.div>

        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-50">
          <ChevronDown className="w-8 h-8" />
        </div>
      </header>

      {/* Input Section */}
      <section id="input-section" className="py-24 px-4 max-w-4xl mx-auto">
        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="bg-slate-900/50 backdrop-blur-xl border border-white/10 rounded-3xl p-8 md:p-12 shadow-2xl"
        >
          <div className="flex items-center gap-3 mb-8">
            <Sparkles className="w-6 h-6 text-indigo-400" />
            <h2 className="text-2xl font-bold">The Vision</h2>
          </div>

          <div className="space-y-8">
            <div>
              <label className="block text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
                Story Idea
              </label>
              <textarea 
                value={storyIdea}
                onChange={(e) => setStoryIdea(e.target.value)}
                placeholder="A detective solving crimes in a futuristic cyberpunk city..."
                className="w-full h-48 bg-black/40 border border-white/10 rounded-2xl p-6 text-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none placeholder:text-slate-600"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
                  Genre
                </label>
                <select 
                  value={genre}
                  onChange={(e) => setGenre(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-4 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none cursor-pointer"
                >
                  {GENRES.map(g => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-3 uppercase tracking-wider">
                  Mood
                </label>
                <select 
                  value={mood}
                  onChange={(e) => setMood(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-xl p-4 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none cursor-pointer"
                >
                  {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>

            <button 
              onClick={handleGenerate}
              disabled={loading || !storyIdea.trim()}
              className="w-full py-6 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-black text-xl rounded-2xl transition-all shadow-lg shadow-indigo-600/20 flex items-center justify-center gap-4 group"
            >
              {loading ? (
                <>
                  <Loader2 className="w-6 h-6 animate-spin" />
                  <span>AI IS CRAFTING YOUR STORY...</span>
                </>
              ) : (
                <>
                  <Clapperboard className="w-6 h-6 group-hover:rotate-12 transition-transform" />
                  <span>GENERATE FILM BLUEPRINT</span>
                </>
              )}
            </button>
          </div>
        </motion.div>
      </section>

      {/* Results Dashboard */}
      <AnimatePresence>
        {blueprint && (
          <motion.section 
            ref={resultsRef}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="py-24 px-4 max-w-7xl mx-auto"
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
              <div>
                <h2 className="text-4xl font-black mb-2">PRODUCTION BLUEPRINT</h2>
                <p className="text-indigo-400 font-mono text-sm uppercase tracking-widest">
                  Generated by Scriptoria Core v1.0
                </p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => handleExport("txt")}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-bold transition-colors"
                >
                  <Download className="w-4 h-4" /> TXT
                </button>
                <button 
                  onClick={() => handleExport("pdf")}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-bold transition-colors"
                >
                  <Download className="w-4 h-4" /> PDF
                </button>
                <button 
                  onClick={() => handleExport("docx")}
                  className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-sm font-bold transition-colors"
                >
                  <Download className="w-4 h-4" /> DOCX
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ResultCard 
                title="Screenplay Outline" 
                icon={<ScrollText className="w-6 h-6" />} 
                content={blueprint.screenplay} 
              />
              <ResultCard 
                title="Character Profiles" 
                icon={<Users className="w-6 h-6" />} 
                content={blueprint.characters} 
              />
              <ResultCard 
                title="Sound Design Plan" 
                icon={<Music className="w-6 h-6" />} 
                content={blueprint.soundDesign} 
              />
              <ResultCard 
                title="Production Notes" 
                icon={<Camera className="w-6 h-6" />} 
                content={blueprint.productionNotes} 
              />
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      <footer className="py-12 border-t border-white/5 text-center text-slate-600 text-sm">
        <p>© 2026 SCRIPTORIA. ALL RIGHTS RESERVED.</p>
      </footer>
    </div>
  );
}

function ResultCard({ title, icon, content }: { title: string; icon: React.ReactNode; content: string }) {
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-slate-900/40 border border-white/5 rounded-3xl p-8 flex flex-col h-[500px]"
    >
      <div className="flex items-center gap-4 mb-6">
        <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400">
          {icon}
        </div>
        <h3 className="text-xl font-bold uppercase tracking-tight">{title}</h3>
      </div>
      <div className="flex-1 overflow-y-auto pr-4 custom-scrollbar">
        <div className="text-slate-400 leading-relaxed whitespace-pre-wrap font-light">
          {content}
        </div>
      </div>
    </motion.div>
  );
}
